import { Card, CardContent } from '@/components/ui/card';
import { Users, Target, Eye, MapPin, Car, Utensils, Zap, Shield } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-primary/90 to-orange-600 text-white py-16">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 text-center">About Us</h1>
          <p className="text-center text-xl text-white/90 max-w-3xl mx-auto">
            Where authentic Tamil flavors meet the comfort and convenience every highway traveler deserves
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        {/* Welcome Section */}
        <div className="max-w-4xl mx-auto mb-16">
          <Card>
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <Utensils className="h-8 w-8 text-primary" />
                <h2 className="text-3xl font-bold text-gray-900">Tn72 NH Restaurants</h2>
              </div>
              <div className="prose max-w-none text-gray-700 leading-relaxed space-y-4">
                <p>
                  Welcome to <strong>Tn72 NH Restaurants</strong>, where authentic Tamil flavors meet the comfort and 
                  convenience every highway traveler deserves. Located along NH routes, we are proud to serve freshly 
                  prepared, hygienic, and delicious meals to families, travelers, and food lovers on the move.
                </p>
                <p>
                  At Tn72 NH Restaurants, we believe that a highway stop should be more than just a break — it should 
                  be a satisfying dining experience. From traditional South Indian meals to flavorful biryanis and 
                  refreshing beverages, every dish is prepared with quality ingredients and care.
                </p>
                <p>
                  We are committed to offering a clean environment, quick service, and a welcoming atmosphere for all 
                  our guests.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Highway Traveler Focus */}
        <div className="mb-16">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-3">
              <Car className="h-8 w-8 text-primary" />
              <h2 className="text-3xl font-bold text-gray-900">Highway Traveler Focus</h2>
            </div>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Highway journeys can be long and tiring. At Tn72 NH Restaurants, we focus on making every stop 
              refreshing and memorable.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {[
              { icon: Users, title: 'Spacious Family Seating', desc: 'Comfortable seating arrangements for families and groups' },
              { icon: Shield, title: 'Hygienic Restrooms', desc: 'Clean and well-maintained facilities' },
              { icon: Car, title: 'Ample Parking Space', desc: 'Safe parking for all types of vehicles' },
              { icon: Zap, title: 'Fast & Efficient Service', desc: 'Quick service to get you back on the road' },
              { icon: Utensils, title: 'Freshly Prepared Food', desc: 'Every dish made fresh with quality ingredients' },
              { icon: MapPin, title: 'Safe Environment', desc: 'Comfortable and secure dining atmosphere' },
            ].map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <feature.icon className="h-12 w-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold text-lg mb-2 text-gray-900">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-8 max-w-3xl mx-auto">
            <Card className="bg-primary/5 border-primary/20">
              <CardContent className="p-6 text-center">
                <p className="text-lg font-medium text-gray-900">
                  Our goal is to become the most trusted highway dining destination for travelers across Tamil Nadu and beyond.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Vision & Mission */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Vision */}
          <Card className="bg-gradient-to-br from-primary/10 to-orange-50">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <Eye className="h-8 w-8 text-primary" />
                <h2 className="text-2xl font-bold text-gray-900">Our Vision</h2>
              </div>
              <p className="text-gray-700 leading-relaxed mb-4">
                To become the leading highway restaurant brand in Tamil Nadu, known for authentic taste, exceptional 
                hygiene standards, and outstanding customer satisfaction.
              </p>
              <p className="text-gray-700 leading-relaxed">
                We envision Tn72 NH Restaurants as a preferred stop for every traveler seeking quality food and comfort 
                on the highway.
              </p>
            </CardContent>
          </Card>

          {/* Mission */}
          <Card className="bg-gradient-to-br from-orange-50 to-primary/10">
            <CardContent className="p-8">
              <div className="flex items-center gap-3 mb-6">
                <Target className="h-8 w-8 text-primary" />
                <h2 className="text-2xl font-bold text-gray-900">Our Mission</h2>
              </div>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>To serve fresh, hygienic, and high-quality food every day</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>To provide quick and friendly service to all customers</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>To maintain a clean, safe, and family-friendly environment</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>To preserve and promote authentic Tamil cuisine</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary mt-1">✓</span>
                  <span>To continuously improve based on customer feedback</span>
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
