import { useState, useMemo } from 'react';
import { Hero } from '@/components/layout/Hero';
import { FilterBar } from '@/components/features/FilterBar';
import { RestaurantGrid } from '@/components/features/RestaurantGrid';
import { RESTAURANTS } from '@/constants/restaurants';
import type { CuisineType, LocationType } from '@/types/restaurant';

export function HomePage() {
  const [selectedCuisine, setSelectedCuisine] = useState<CuisineType>('All');
  const [selectedLocation, setSelectedLocation] = useState<LocationType>('All');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRestaurants = useMemo(() => {
    return RESTAURANTS.filter((restaurant) => {
      const cuisineMatch = selectedCuisine === 'All' || restaurant.cuisine === selectedCuisine;
      const locationMatch = selectedLocation === 'All' || restaurant.location === selectedLocation;
      
      const searchMatch = searchQuery === '' || 
        restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        restaurant.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      return cuisineMatch && locationMatch && searchMatch;
    });
  }, [selectedCuisine, selectedLocation, searchQuery]);

  return (
    <>
      <Hero />
      <FilterBar
        selectedCuisine={selectedCuisine}
        selectedLocation={selectedLocation}
        searchQuery={searchQuery}
        onCuisineChange={setSelectedCuisine}
        onLocationChange={setSelectedLocation}
        onSearchChange={setSearchQuery}
      />
      <main className="flex-grow bg-gray-50">
        <RestaurantGrid restaurants={filteredRestaurants} />
      </main>
    </>
  );
}
