export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: string;
  category: MenuCategory;
  featured?: boolean;
  vegetarian?: boolean;
  spicy?: boolean;
}

export type MenuCategory = 
  | 'Breakfast'
  | 'Lunch'
  | 'Dinner'
  | 'Special Briyani'
  | 'Beverages'
  | 'Combos Meals'
  | 'Briyani'
  | 'Tiffin'
  | 'Fresh Juices'
  | 'Filter Coffee';
