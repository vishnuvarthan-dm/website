export interface Restaurant {
  id: string;
  name: string;
  cuisine: string;
  location: string;
  address: string;
  phone: string;
  hours: string;
  description: string;
  priceRange: string;
  rating: number;
  image: string;
  featured: boolean;
  amenities?: string[];
  diningOptions?: string[];
  services?: string[];
  specialOfferings?: string[];
}

export type CuisineType = 'All' | 'American' | 'Italian' | 'Asian' | 'Mexican' | 'Seafood';
export type LocationType = 'All' | 'Nanguneri' | 'Tirunelveli' | 'Panakudi' | 'Vadakkuvalliyur' | 'Kavalkinaru' | 'Woodsville';
