export function Hero() {
  return (
    <div className="relative bg-gradient-to-br from-primary/90 to-orange-600 text-white overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=1600&q=80')] bg-cover bg-center opacity-20"></div>
      <div className="relative container mx-auto px-4 py-16 md:py-24">
        <div className="max-w-3xl">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
            Your Trusted Highway Dining Destination
          </h2>
          <p className="text-lg md:text-xl text-white/90 mb-6 leading-relaxed">
            Authentic Tamil flavors meet comfort and convenience. Fresh, hygienic meals prepared daily for travelers across Tamil Nadu's highway network.
          </p>
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
              <span className="font-semibold">7</span> Locations
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
              <span className="font-semibold">50+</span> Menu Items
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-lg px-4 py-2">
              <span className="font-semibold">100%</span> Hygienic
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
