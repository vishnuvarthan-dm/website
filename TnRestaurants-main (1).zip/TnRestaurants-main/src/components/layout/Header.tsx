import { Utensils } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';

export function Header() {
  const location = useLocation();
  
  const isActive = (path: string) => location.pathname === path;
  
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div className="bg-primary rounded-lg p-2">
              <Utensils className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Tn72 NH Restaurants</h1>
              <p className="text-xs text-muted-foreground">Tamil Nadu Highway Dining</p>
            </div>
          </Link>
          <nav className="flex items-center gap-2">
            <Link to="/">
              <Button 
                variant={isActive('/') ? 'default' : 'ghost'}
                size="sm"
              >
                Home
              </Button>
            </Link>
            <Link to="/menu">
              <Button 
                variant={isActive('/menu') ? 'default' : 'ghost'}
                size="sm"
              >
                Menu
              </Button>
            </Link>
            <Link to="/about">
              <Button 
                variant={isActive('/about') ? 'default' : 'ghost'}
                size="sm"
              >
                About Us
              </Button>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
