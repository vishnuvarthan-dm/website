import { Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import type { CuisineType, LocationType } from '@/types/restaurant';

interface FilterBarProps {
  selectedCuisine: CuisineType;
  selectedLocation: LocationType;
  searchQuery: string;
  onCuisineChange: (cuisine: CuisineType) => void;
  onLocationChange: (location: LocationType) => void;
  onSearchChange: (query: string) => void;
}

const cuisines: CuisineType[] = ['All', 'American', 'Italian', 'Asian', 'Mexican', 'Seafood'];
const locations: LocationType[] = ['All', 'Nanguneri', 'Tirunelveli', 'Panakudi', 'Vadakkuvalliyur', 'Kavalkinaru', 'Woodsville'];

export function FilterBar({
  selectedCuisine,
  selectedLocation,
  searchQuery,
  onCuisineChange,
  onLocationChange,
  onSearchChange,
}: FilterBarProps) {
  return (
    <div className="bg-white border-b border-gray-200 py-6">
      <div className="container mx-auto px-4">
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Search Restaurants</h3>
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by name or description..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Cuisine Type</h3>
            <div className="flex flex-wrap gap-2">
              {cuisines.map((cuisine) => (
                <Button
                  key={cuisine}
                  variant={selectedCuisine === cuisine ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onCuisineChange(cuisine)}
                  className="transition-all"
                >
                  {cuisine}
                </Button>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-700 mb-2">Location</h3>
            <div className="flex flex-wrap gap-2">
              {locations.map((location) => (
                <Button
                  key={location}
                  variant={selectedLocation === location ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onLocationChange(location)}
                  className="transition-all"
                >
                  {location}
                </Button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
