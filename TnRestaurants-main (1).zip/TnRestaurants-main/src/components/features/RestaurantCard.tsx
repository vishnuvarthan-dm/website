import { MapPin, Phone, Clock, Star, DollarSign } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { Restaurant } from '@/types/restaurant';

interface RestaurantCardProps {
  restaurant: Restaurant;
}

export function RestaurantCard({ restaurant }: RestaurantCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-xl transition-shadow duration-300 group">
      <div className="relative h-48 overflow-hidden">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {restaurant.featured && (
          <Badge className="absolute top-3 right-3 bg-primary text-white">
            Featured
          </Badge>
        )}
        <div className="absolute bottom-3 left-3">
          <Badge variant="secondary" className="bg-white/90 backdrop-blur-sm">
            {restaurant.cuisine}
          </Badge>
        </div>
      </div>
      
      <CardContent className="p-5">
        <div className="flex items-start justify-between mb-3">
          <h3 className="text-xl font-bold text-gray-900 leading-tight">
            {restaurant.name}
          </h3>
          <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded">
            <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
            <span className="text-sm font-semibold text-amber-700">{restaurant.rating}</span>
          </div>
        </div>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">
          {restaurant.description}
        </p>
        
        <div className="space-y-2 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="h-4 w-4 text-primary flex-shrink-0" />
            <span className="truncate">{restaurant.address}</span>
          </div>
          
          <div className="flex items-center gap-2 text-gray-600">
            <Phone className="h-4 w-4 text-primary flex-shrink-0" />
            <span>{restaurant.phone}</span>
          </div>
          
          <div className="flex items-center gap-2 text-gray-600">
            <Clock className="h-4 w-4 text-primary flex-shrink-0" />
            <span className="text-xs">{restaurant.hours}</span>
          </div>
          
          <div className="flex items-center gap-2 text-gray-600 pt-2 border-t">
            <DollarSign className="h-4 w-4 text-primary flex-shrink-0" />
            <span className="font-medium">{restaurant.priceRange}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
