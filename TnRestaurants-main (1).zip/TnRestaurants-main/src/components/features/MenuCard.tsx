import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Leaf, Flame } from 'lucide-react';
import type { MenuItem } from '@/types/menu';

interface MenuCardProps {
  item: MenuItem;
}

export function MenuCard({ item }: MenuCardProps) {
  return (
    <Card className="hover:shadow-lg transition-shadow duration-300">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3 mb-2">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
              {item.vegetarian && (
                <Leaf className="h-4 w-4 text-green-600" />
              )}
              {item.spicy && (
                <Flame className="h-4 w-4 text-red-500" />
              )}
            </div>
            <p className="text-sm text-gray-600 leading-relaxed">{item.description}</p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <span className="text-lg font-bold text-primary whitespace-nowrap">{item.price}</span>
            {item.featured && (
              <Badge variant="secondary" className="text-xs">
                Popular
              </Badge>
            )}
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-gray-100">
          <Badge variant="outline" className="text-xs">
            {item.category}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
